<?php get_header(); ?>
		
		
		
		<br/>


					<!-- get the post -->
					<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
	

			<!-- display the 100% width featured image -->
			<div class="image-wrap" id="featured-wrapper">
				<?php the_post_thumbnail('full', array('class' => 'article-hero-img')); ?>
			</div>

					
			<div class="row">		
						    
						<div class="large-12 small-12 columns" id="page">
					    <div <?php post_class() ?> id="post-<?php the_ID(); ?>">
					        <div id="">

				        		<h2><?php the_title(); ?></h2>
					            <?php the_content(); ?>
					        </div>
					

					    </div>
					    </div>
					    <?php endwhile; endif; ?>

			    	
			</div>
			
			
			<?php wp_reset_postdata(); ?>

	<?php get_footer(); ?>
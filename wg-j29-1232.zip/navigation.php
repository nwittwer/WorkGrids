</div>
</div>	


<header class="site-header">
	<div class="row">
		<div class="large-12 columns">
			<hgroup>
				<!--<a href="http://nickwittwer.com"><img id="logo" src="<?php bloginfo('template_directory'); ?>/img/logo.png"/></a>-->
				<a href="<?php echo home_url(); ?>"><h3 id="logo" class="bold">WorkGrids</h3></a>
			</hgroup>
		
			<nav id="nav">
				<ul>
					<li class="<?php if (is_home()){ echo "active";}?>">
						<a href="<?php echo home_url(); ?>">Home</a> <span class="nav-divider">/</span> 
					</li>
					
					<li class="<?php if (is_page('about')){ echo "active";}?>">
						<a href="<?php echo home_url();?>/grid">The Grid</a> <span class="nav-divider">/</span> 
					</li>
					
					<li class="<?php if (is_page('about')){ echo "active";}?>">
						<a href="<?php echo home_url();?>/wallpapers">Wallpapers</a> <span class="nav-divider"></span> 
					</li>
					
					
					<!-- if user is logged in, display profile link in nav -->
					<?php global $user_login; get_currentuserinfo();
					if ($user_login) :?>
					<span class="nav-divider">/</span> <li><a href="<?php echo home_url() . '/u/' . get_the_author_meta( 'user_login', wp_get_current_user()->ID ); ?>" >Profile</a></li>
					<?php endif; ?>

					
					<!--<li class="<?php if (is_page('projects')){ echo "active";}?>">
						<a href="<?php echo home_url();?>/projects">Projects</a> 
					</li>-->
					
				</ul>
			</nav>
		</div>
	</div>
	
</header>